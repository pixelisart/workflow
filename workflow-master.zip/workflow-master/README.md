# My Personal Workflow with SASS, NPM and Gulp
My Web Workflow with NPM, SASS, Gulp and More

#Instructions
1.- Clone this repo or download it from this website.

2.- Make sure you have these installed:
    - [node.js](http://nodejs.org/)
    - [git](http://git-scm.com/)
    - [gulp](http://gulpjs.com/)
    
3.- Run `npm install ` to install the project dependencies   
